# coding=utf-8

import base64
from datetime import date
from createjsonmodule import helpers

# MODULE INFORMATION
MODULE_NAME = "createjsonmodule/"

# ISSUER INFORMATION
ISSUER_URL = "http://media.mit.edu"
ISSUER_CERTS_URL = "http://coins.media.mit.edu"
ISSUER_PUBLIC_KEY_URL = "http://coins.media.mit.edu/keys/ml-certs-public-key.asc"
ISSUER_SIGNATURE_IMAGE = helpers.encode_image(MODULE_NAME+"img/signature.png")
ISSUER_EMAIL = "coins@media.mit.edu"
ISSUER_NAME = "MIT Media Lab"
ISSUER_ID = "https://coins.media.mit.edu/issuer/ml-issuer.json"

# CERTIFICATE INFORMATION
CERTIFICATE_LANGUAGE = "en-US" #LANGUAGE AND COUNTRY INFORMATION
CERTIFICATE_DESCRIPTION = ""
CERTIFICATE_SUBTITLE = ""
CERTIFICATE_TITLE = ""
CERTIFICATE_IMAGE = helpers.encode_image(MODULE_NAME+"img/header.png") # this should be a 30th anniversary / alum logo
CERTIFICATE_HEADER_IMAGE= helpers.encode_image(MODULE_NAME+"img/header.png")
CERTIFICATE_ID = ISSUER_CERTS_URL + "/criteria/2015/10/alumni.json"