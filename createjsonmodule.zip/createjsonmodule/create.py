import json
import csv
from datetime import date
import base64
from createjsonmodule import config
import copy
from createjsonmodule import helpers
from createjsonmodule import testobject

def create_recipient(person):
	print person
	recipient = {
		"type": "email",
		"familyName": person["name"]["familyName"],
		"givenName": person["name"]["givenName"],
		"pubkey": person["pubkey"],
		"identity": person["email"],
		"hashed": False
	}
	return recipient

def create_assertion(uid, issued_on=str(date.today())):
	assertion = {
			"issuedOn": issued_on,
			"image:signature": config.ISSUER_SIGNATURE_IMAGE,
			"uid": uid,
			"id": config.ISSUER_CERTS_URL+"/"+uid,
			"evidence": {
				"type": "url",
				"data": config.ISSUER_CERTS_URL+"/"+uid+"/evidence"
			}
		}
	return assertion


def create_certificate():
	certificate = {
		"subtitle": {
	      	"content": config.CERTIFICATE_SUBTITLE,
	      	"display": True
	    },
	    "title": config.CERTIFICATE_TITLE,
	    "language": config.CERTIFICATE_LANGUAGE,
	    "image": config.CERTIFICATE_HEADER_IMAGE,
	    "description": config.CERTIFICATE_DESCRIPTION,
	    "id": config.CERTIFICATE_ID,
	    "issuer": {
	    	"url": config.ISSUER_URL,
	    	"image": config.CERTIFICATE_HEADER_IMAGE,
	    	"email": config.ISSUER_EMAIL,
	    	"name": config.ISSUER_NAME,
	    	"id": config.ISSUER_ID
	    }
	}
	return certificate

def create_verification():
	verify = {
		"signer": config.ISSUER_PUBLIC_KEY_URL,
		"attribute-signed": "uid",
    	"type": "ECDSA(secp256k1)"
	}
	return verify

def make_raw_json(recipient, assertion, certificate, verify):
	raw_json = {
		"recipient": recipient,
		"assertion": assertion,
		"certificate": certificate,
		"verify": verify
	}
	return raw_json

def run(data):
	# Please ensure that all UID ObjectIDs are in string form
	person = data["user"]
	uid = str(data["_id"])
	verify = create_verification()
	certificate = create_certificate()
	recipient = create_recipient(person)
	assertion = create_assertion(uid)
	raw_json = make_raw_json(recipient, assertion, certificate, verify)
	data["json"] = json.dumps(raw_json, ensure_ascii=True)
	return data
