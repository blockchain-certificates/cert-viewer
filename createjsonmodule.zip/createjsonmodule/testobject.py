import json
from bson.objectid import ObjectId

jsonstring ='{"_id":"561e84c27cce12b284e300b9","json":null,"issued":false,"txid":null,"user":{"username":"jnazare","email":"juliana@media.mit.edu","pubkey":"","name":{"givenName":"Juliana","familyName":"Nazare"}}}'
person = json.loads(jsonstring)